Realizado por Joselyn Nieva Morales
Aplicaciones:
-Positivo/Negativo
-Par/Impar
-Hipotenusa
-Numeros naturales