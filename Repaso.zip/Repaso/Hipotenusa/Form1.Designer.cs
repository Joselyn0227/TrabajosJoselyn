﻿namespace Hipotenusa
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEnviar = new System.Windows.Forms.Button();
            this.Instruccion = new System.Windows.Forms.Label();
            this.txtCatetoA = new System.Windows.Forms.TextBox();
            this.txtCatetoB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnEnviar
            // 
            this.btnEnviar.Location = new System.Drawing.Point(221, 157);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(75, 23);
            this.btnEnviar.TabIndex = 0;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // Instruccion
            // 
            this.Instruccion.AutoSize = true;
            this.Instruccion.Location = new System.Drawing.Point(54, 48);
            this.Instruccion.Name = "Instruccion";
            this.Instruccion.Size = new System.Drawing.Size(418, 13);
            this.Instruccion.TabIndex = 1;
            this.Instruccion.Text = "Para hallar la hipotenusa de un triángulo, ingrese el valor de los catetos a cont" +
    "inuación:";
            // 
            // txtCatetoA
            // 
            this.txtCatetoA.Location = new System.Drawing.Point(208, 76);
            this.txtCatetoA.Name = "txtCatetoA";
            this.txtCatetoA.Size = new System.Drawing.Size(100, 20);
            this.txtCatetoA.TabIndex = 2;
            this.txtCatetoA.Text = "Cateto1";
            // 
            // txtCatetoB
            // 
            this.txtCatetoB.Location = new System.Drawing.Point(208, 115);
            this.txtCatetoB.Name = "txtCatetoB";
            this.txtCatetoB.Size = new System.Drawing.Size(100, 20);
            this.txtCatetoB.TabIndex = 3;
            this.txtCatetoB.Text = "Cateto 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 293);
            this.Controls.Add(this.txtCatetoB);
            this.Controls.Add(this.txtCatetoA);
            this.Controls.Add(this.Instruccion);
            this.Controls.Add(this.btnEnviar);
            this.Name = "Form1";
            this.Text = "Hipotenusa";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.Label Instruccion;
        private System.Windows.Forms.TextBox txtCatetoA;
        private System.Windows.Forms.TextBox txtCatetoB;
    }
}

