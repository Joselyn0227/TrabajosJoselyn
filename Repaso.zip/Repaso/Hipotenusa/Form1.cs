﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hipotenusa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Aplicación para conocer la hipotenusa de un triángulo rectángulo a partir del valor de los catetos
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnviar_Click(object sender, EventArgs e)
        {
            // Variables para almacenar las longitudes de los catetos y la hipotenusa
            double catetoA, catetoB, hipotenusa;

            // Intenta convertir las entradas de texto en números
            if (double.TryParse(txtCatetoA.Text, out catetoA) && double.TryParse(txtCatetoB.Text, out catetoB))
            {
                // Calcula la hipotenusa usando el teorema de Pitágoras
                hipotenusa = Math.Sqrt(catetoA * catetoA + catetoB * catetoB);

                // Muestra el resultado en un MessageBox
                MessageBox.Show($"La hipotenusa es: {hipotenusa:F2}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Muestra un MessageBox de error si las entradas no son válidas
                MessageBox.Show("Por favor, ingrese valores válidos en los catetos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
