﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _100Numeros
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Aplicación para escribir los primeros 100 números naturales
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnMostrar_Click(object sender, EventArgs e)
        {
            string resultado = "";

            for (int i = 1; i <= 100; i++)
            {
                resultado += i.ToString() + " ";

                // Agregar un salto de línea cada 10 números para que sea más legible
                if (i % 10 == 0)
                {
                    resultado += Environment.NewLine;
                }
            }

            MessageBox.Show(resultado, "Primeros 100 Números Naturales");
        }
    }
}
