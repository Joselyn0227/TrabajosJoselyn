﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParImpar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Aplicación para leer un valor cualquiera N y escribir si dicho número es par o impar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnviar_Click(object sender, EventArgs e)
        {
            ///Variable para almacenar el numero de entrada
            string input = txtNumero.Text;
            string mensaje;

            ///Convertir cadena a entero sin excepciones durante la ejecución
            if (int.TryParse(input, out int numero))
            {
                if (numero % 2 == 0)
                {
                    mensaje = "El número es par";
                }
                else
                {
                    mensaje = "El número es impar";
                }
            }
            // Muestra un MessageBox de error si la entradas no es válida
            else
            {
                mensaje = "El valor ingresado no es válido. Intente nuevamente";
            }
            //Muestra el resultado
            MessageBox.Show(mensaje, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
