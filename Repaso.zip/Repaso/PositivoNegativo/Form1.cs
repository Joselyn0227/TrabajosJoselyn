﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Repaso
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Aplicación para leer un valor cualquiera N y escribir en la pantalla si dicho número es Positivo o Negativo
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string input = txtNumero.Text;
            string mensaje;

            if (int.TryParse(input, out int numero))
            {
                if (numero > 0)
                {
                    mensaje = "El número es positivo";
                }
                else if (numero < 0)
                {
                    mensaje = "El número es negativo";
                }
                else
                {
                    mensaje = "El número es neutro";
                }
            }
            else
            {
                mensaje = "El valor ingresado no es válido. Intente nuevamente";
            }

            MessageBox.Show(mensaje, "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
