﻿namespace Repaso
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Instruccion = new System.Windows.Forms.Label();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Instruccion
            // 
            this.Instruccion.AutoSize = true;
            this.Instruccion.Location = new System.Drawing.Point(104, 48);
            this.Instruccion.Name = "Instruccion";
            this.Instruccion.Size = new System.Drawing.Size(202, 13);
            this.Instruccion.TabIndex = 0;
            this.Instruccion.Text = "Ingrese cualquier número a continuación:";
            // 
            // txtNumero
            // 
            this.txtNumero.Location = new System.Drawing.Point(156, 82);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(96, 20);
            this.txtNumero.TabIndex = 1;
            this.txtNumero.Text = "Ej: 123";
            // 
            // btnEnviar
            // 
            this.btnEnviar.Location = new System.Drawing.Point(172, 127);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(67, 23);
            this.btnEnviar.TabIndex = 2;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            this.btnEnviar.Click += new System.EventHandler(this.btnEnviar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 216);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.Instruccion);
            this.Name = "Form1";
            this.Text = "Positivo o Negativo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Instruccion;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.Button btnEnviar;
    }
}

