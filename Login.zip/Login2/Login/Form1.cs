﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Login
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        /// <summary>
        ///     Creación de login con validación de claves
        ///     Por Joselyn Nieva Morales
        /// </summary>
        private int intentos = 0;
        SqlConnection conexion = new SqlConnection("server=JOSELYN;database=DB_Ingreso; integrated security=true");
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            ///Abre la conexión con la bas de datos
            conexion.Open();
            string consulta = "select * from tbl_user where usuario='" + txtUser.Text + "' and contraseña='" + txtPassword.Text + "'";

            using (SqlCommand comando = new SqlCommand(consulta, conexion))
            {
                //Utiliza parámetros para validar las entradas y evitar infiltración de código
                comando.Parameters.AddWithValue("usuario", txtUser.Text);
                comando.Parameters.AddWithValue("contraseña", txtPassword.Text);

                SqlDataReader lector = comando.ExecuteReader();

                if (lector.HasRows)
                {
                    MessageBox.Show("Ingreso satisfactorio");
                    // Si los datos ingresados son correctos, en pantalla aparecerá un mensaje que indica que el acceso fue satisfactorio
                }
                else
                {
                    intentos++; //El contador de intentos incrementa
                    if (intentos >= 3) // Máximo 3 intentos
                    {
                        MessageBox.Show("Ha excedido el número máximo de intentos. La aplicación se cerrará.", "No se pudo iniciar sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Application.Exit();
                    }
                    else
                    {
                        MessageBox.Show("Usuario o contraseña incorrectos. Intentos restantes: " + (3 - intentos), "No se pudo iniciar sesión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
            }
            ///Se cierra la conexión
            conexion.Close();
        }
    }
}
