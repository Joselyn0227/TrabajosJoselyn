﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpaceInvaders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Boolean limite;
        int x;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (limite == false)
            {
                x += 10;
                imgNave.Location = new Point(x, imgNave.Location.Y);
                if (x > 450)
                {
                    limite = true;
                }
            }
            if (limite == true)
            {
                x -= 10;
                imgNave.Location = new Point(x, imgNave.Location.Y);
                if (x < 40)
                {
                    limite = false;
                }
            }

        }
    }
}