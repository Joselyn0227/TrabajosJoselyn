﻿namespace SpaceInvaders
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.imgNave = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.imgNave)).BeginInit();
            this.SuspendLayout();
            // 
            // imgNave
            // 
            this.imgNave.BackColor = System.Drawing.Color.Transparent;
            this.imgNave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.imgNave.Image = global::WindowsFormsApp3.Properties.Resources.naveClasica__1___1_1;
            this.imgNave.Location = new System.Drawing.Point(247, 398);
            this.imgNave.Name = "imgNave";
            this.imgNave.Size = new System.Drawing.Size(101, 141);
            this.imgNave.TabIndex = 1;
            this.imgNave.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(594, 575);
            this.Controls.Add(this.imgNave);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Spacial Game";
            ((System.ComponentModel.ISupportInitialize)(this.imgNave)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox imgNave;
        private System.Windows.Forms.Timer timer1;
    }
}

