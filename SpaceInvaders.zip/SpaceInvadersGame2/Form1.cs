﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SpaceInvadersGame
{
    public partial class Form1 : Form
    {
        private int puntoX;
        private int puntoY;
        private const int velocidadNave = 5;
        private const int velocidadBala = 30;
        private bool disparando = false;

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            puntoX = (ClientSize.Width - imgNave.Width) / 2;
            puntoY = ClientSize.Height - imgNave.Height - 20;
            imgNave.Location = new Point(puntoX, puntoY);
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Left:
                    puntoX -= velocidadNave;
                    break;
                case Keys.Right:
                    puntoX += velocidadNave;
                    break;
                case Keys.Space:
                    if (!disparando)
                    {
                        disparando = true;
                        disparaBala();
                    }
                    break;
            }

            puntoX = Math.Max(0, Math.Min(ClientSize.Width - imgNave.Width, puntoX));
            puntoY = Math.Max(0, Math.Min(ClientSize.Height - imgNave.Height, puntoY));

            imgNave.Location = new Point(puntoX, puntoY);
        }

        private void disparaBala()
        {
            PictureBox imgBala = new PictureBox();
            imgBala.Image = WindowsFormsApp4.Properties.Resources.imgBala;
            imgBala.SizeMode = PictureBoxSizeMode.AutoSize;
            imgBala.Location = new Point(puntoX + imgNave.Width / 2 - imgBala.Width / 2, puntoY);
            Controls.Add(imgBala);

            Timer balaTimer = new Timer();
            balaTimer.Interval = 30;
            balaTimer.Tick += (s, e) =>
            {
                imgBala.Top -= velocidadBala;
                if (imgBala.Top + imgBala.Height < 0)
                {
                    balaTimer.Stop();
                    balaTimer.Dispose();
                    Controls.Remove(imgBala);
                    disparando = false;
                }
            };

            balaTimer.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeGame();
        }
    }
}
