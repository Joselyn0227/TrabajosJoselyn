﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnMovimiento_mouse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMovimiento_mouse
            // 
            this.btnMovimiento_mouse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnMovimiento_mouse.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnMovimiento_mouse.Font = new System.Drawing.Font("High Tower Text", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMovimiento_mouse.ForeColor = System.Drawing.SystemColors.Menu;
            this.btnMovimiento_mouse.Location = new System.Drawing.Point(127, 126);
            this.btnMovimiento_mouse.Name = "btnMovimiento_mouse";
            this.btnMovimiento_mouse.Size = new System.Drawing.Size(178, 51);
            this.btnMovimiento_mouse.TabIndex = 1;
            this.btnMovimiento_mouse.Text = "¡PRESIÓNAME!";
            this.btnMovimiento_mouse.UseVisualStyleBackColor = false;
            this.btnMovimiento_mouse.MouseEnter += new System.EventHandler(this.btnMovimiento_mouse_MouseEnter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(435, 312);
            this.Controls.Add(this.btnMovimiento_mouse);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMovimiento_mouse;
    }
}
