﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private Timer temporizador = new Timer();

        public Form1()
        {
            InitializeComponent();
            // Configurar el temporizador
            temporizador.Interval = 3000; // 3 segundos
            temporizador.Tick += Temporizador_Tick;
        }

        private void Temporizador_Tick(object sender, EventArgs e)
        {
            // Mostrar el MessageBox cuando el temporizador expire
            MessageBox.Show("¡upss!");
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            // Reiniciar el temporizador cuando se detecta movimiento
            temporizador.Stop();
            temporizador.Start();
        }

        private void Form1_MouseLeave(object sender, EventArgs e)
        {
            // Detener el temporizador cuando el cursor sale del formulario
            temporizador.Stop();
        }

        private void btnMovimiento_mouse_MouseEnter(object sender, EventArgs e)
        {
            Random rand = new Random();
            int screenWidth = Screen.PrimaryScreen.Bounds.Width;
            int screenHeight = Screen.PrimaryScreen.Bounds.Height;

            for (int i = 0; i < 100; i++)
            {
                int randomX = rand.Next(screenWidth);
                int randomY = rand.Next(screenHeight);
                Cursor.Position = new System.Drawing.Point(randomX, randomY);
                System.Threading.Thread.Sleep(100);
            }
            MessageBox.Show("¡UPSSS!");
        }
    }
}
