﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NachoOpera;

namespace Integrando
{
    class Program
    {
        static void Main(string[] args)
        {
            // Llamar a la función Suma de Class1
            long suma = Class1.Suma(5, 2);
            Console.WriteLine($"Suma: {suma}");

            // Llamar a la función Resta de Class2
            long resta = Class2.Resta(10, 4);
            Console.WriteLine($"Resta: {resta}");

            // Llamar a la función Multiplicacion de Class3
            long multiplicacion = Class3.Multiplicacion(8, 7);
            Console.WriteLine($"Multiplicación: {multiplicacion}");

            // Llamar a la función Division de Class4
            long division = Class4.Division(15, 5);
            Console.WriteLine($"División: {division}");

            Console.ReadKey();
        }
    }
}
