﻿namespace NachoOpera
{
    public class Class1
    {
        /// <summary>
        /// Operación Suma
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static long Suma(int i, int j)
        {
            return i + j;
        }
    }
    public class Class2
    {
        /// <summary>
        /// Operación Resta
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static long Resta(int i, int j)
        {
            return i - j;
        }
    }
    public class Class3
    {
        /// <summary>
        /// Operación Multiplicación
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static long Multiplicacion(int i, int j)
        {
            return i * j;
        }
    }
    public class Class4
    {
        /// <summary>
        /// Operación División
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns></returns>
        public static long Division(int i, int j)
        {
            return i / j;
        }
    }
}